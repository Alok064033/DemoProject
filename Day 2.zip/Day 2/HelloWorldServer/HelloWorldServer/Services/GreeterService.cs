using Grpc.Core;
using HelloWorldServer;

namespace HelloWorldServer.Services
{
    public class GreeterService : Greeter.GreeterBase
    {
        private readonly ILogger<GreeterService> _logger;
        public GreeterService(ILogger<GreeterService> logger)
        {
            _logger = logger;
        }

        public override Task<HelloReply> SayHello(HelloRequest request, ServerCallContext context)
        {
            return Task.FromResult(new HelloReply
            {
                Message = "Hello " + request.Name
            });
        }

        public override Task<AddReply> Add(AddRequest request, ServerCallContext context)
        {
            return Task.FromResult( new AddReply() { Sum = request.I + request.J });
           // return base.Add(request, context);
        }

        public override async Task SayHelloStream(HelloRequest request, IServerStreamWriter<HelloReply> responseStream, ServerCallContext context)
        {
            while (!context.CancellationToken.IsCancellationRequested)
            {
               await  responseStream.WriteAsync(new HelloReply() { Message = DateTime.Now.ToString() });
               await Task.Delay(1000);
            }
        }
    }
}