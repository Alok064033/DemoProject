﻿using Grpc.Core;
using Grpc.Net.Client;
using HelloWorldServer;

namespace HelloWorldClient
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.ReadLine();
            var channel = GrpcChannel.ForAddress("https://localhost:7209");
            var client = new Greeter.GreeterClient(channel);
            var response = await client.AddAsync(new AddRequest()
            {
                I = 1,
                J = 2
            });
            Console.WriteLine(response.Sum);
            CancellationTokenSource tokenSource = new CancellationTokenSource();
            var token = tokenSource.Token;
            
           using var call = client.SayHelloStream(new HelloRequest() { Name = "test"},
                new Grpc.Core.CallOptions(cancellationToken: token));

            try
            {
                int i = 0;
                await foreach (var res in call.ResponseStream.ReadAllAsync())
                {
                    await Task.Delay(1500);
                    Console.WriteLine(res.Message);
                    if (i == 10)
                        tokenSource.Cancel();
                    i++;
                }
            }
            catch (RpcException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}