﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PatternsLib;

namespace HelloWorldWebApp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            //var burger =  BurgerFactory.GetBurger(BurgerType.Cheese);
            // var pizza =  PizzaFactory.GetPizza(PizzaType.Cheese);
            //CompositeFoodFactory foodFactory = new CompositeFoodFactory();
            //foodFactory.
        }
    }
}