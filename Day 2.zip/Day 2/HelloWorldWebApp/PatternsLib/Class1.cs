﻿using System.Reflection;
using System.Reflection.Metadata;

namespace PatternsLib
{
    class BurgerCreator
    {
        void Create()
        {
            Burger bruger = new Burger();
            bruger.AddBreadType(BreadType.Multigrain);
            bruger.AddCheese(true);

            Burger bruger2 = new Burger();
            bruger2.AddBreadType(BreadType.Multigrain);
            bruger2.AddCheese(true);
            bruger2.AddIngredients(new string[] { "Onion", "Tomato"});

        }
    }
    public class Burger : IBurger
    {
        public BreadType BreadType { get; set; }
        public bool Cheese { get; set; }
        public string[] Ingredients { get; set; }
        public bool SaltAndPepper { get; set; }

        public void AddBreadType(BreadType breadType) => BreadType = breadType;
        public void AddCheese(bool cheese) => Cheese = cheese;
        public void AddSaltAndPepper(bool value) => SaltAndPepper = value;
        public void AddIngredients(string[] ingredients) => Ingredients = ingredients;

    }
    public enum BreadType
    {
        ParmesanOregano,
        Multigrain
    }

    public interface IBurger    {
        BreadType BreadType { get; set; }
        bool Cheese { get; set; }
        string[] Ingredients { get; set; }
        bool SaltAndPepper { get; set; }
    }
    class CheeseBurger : IBurger
    {
       public BreadType BreadType { get; set; }
       public bool Cheese { get; set; }
       public string[] Ingredients { get; set; }
       public bool SaltAndPepper { get; set; }
        public CheeseBurger()
        {
            BreadType = BreadType.Multigrain;
            Cheese = true;
            Ingredients = new string[] { };
            SaltAndPepper = true;
        }
    }
    class HemBurger : IBurger    {
        public BreadType BreadType { get; set; }
        public bool Cheese { get; set; }
        public string[] Ingredients { get; set; }
        public bool SaltAndPepper { get; set; }
        public HemBurger()
        {
            BreadType = BreadType.Multigrain;
            Cheese = true;
            Ingredients = new string[] { "Hem"};
            SaltAndPepper = true;
        }

    }
    public class BurgerFactory    {
        public static IBurger GetBurger(BurgerType burgerType)
        {
            //var type = Assembly.GetExecutingAssembly().GetType(burgerType.ToString() + "Burger");
            //return Activator.CreateInstance(type);
            switch (burgerType)
            {
                case BurgerType.Cheese:
                    return new CheeseBurger();
                case BurgerType.Hem:
                    return new HemBurger();
                default:
                    throw new ArgumentException("Invalid Burger type");
            }
        }
    }
    public enum BurgerType    {        Cheese,         Hem    }
    public enum PizzaType    {        Cheese,        Hem    }

    public class PizzaFactory
    {
        public static IPizza GetPizza(PizzaType burgerType)
        {
            //var type = Assembly.GetExecutingAssembly().GetType(burgerType.ToString() + "Burger");
            //return Activator.CreateInstance(type);
            switch (burgerType)
            {
                case PizzaType.Cheese:
                    return new CheesePizza();
                case PizzaType.Hem:
                    return new HemPizza();
                default:
                    throw new ArgumentException("Invalid Burger type");
            }
        }
    }
    public interface IPizza
    {

    }
    class CheesePizza : IPizza
    {

    }
    class HemPizza : IPizza
    {

    }

    public class CompositeFoodFactory
    {
        //When using composite factory. Create factory interface and expose rather than exposing concrete factory
        public PizzaFactory PizzaFactory { get; set; }
        public BurgerFactory BurgerFactory { get; set; }
        public CompositeFoodFactory()
        {
            PizzaFactory = new PizzaFactory();
            BurgerFactory = new BurgerFactory();
        }
    }
    public class AbstractFoodFactory
    {
        public static IPizza GetPizza(PizzaType burgerType)
        {
            return PizzaFactory.GetPizza(burgerType);
        }
        public static IBurger GetBurger(BurgerType burgerType)
        {
            return BurgerFactory.GetBurger(burgerType);
        }
    }

    class TextLogger
    {
        static TextLogger _logger;
        static object locker = new object();
        private TextLogger()
        {

        }
        public static TextLogger GetInstance()
        {
            if (_logger == null)
            {
                lock (locker)
                {
                    if (_logger == null)
                        _logger = new TextLogger();
                }
            }
           
            return _logger;
        }
    }
}