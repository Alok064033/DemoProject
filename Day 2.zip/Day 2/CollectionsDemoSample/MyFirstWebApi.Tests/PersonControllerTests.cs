using Moq;
using MyFirstWebApi.Controllers;
using MyFirstWebApi.Models;
using MyFirstWebApi.Repositories;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace MyFirstWebApi.Tests
{
    public class PersonControllerTests
    {
        Mock<IRepository<Person>> _repositoryMock;

        [SetUp]
        public void Setup()
        {
            _repositoryMock = new Mock<IRepository<Person>>();
           
        }

        [Test]
        public void GetShouldReturnResultWhenItemsAreInDatabase()
        {
            //PersonController controller = new PersonController(new DummyRepository());
            _repositoryMock.Setup(x => x.GetAll()).Returns(new List<BaseEntity>()
           {
               new Person(){Id =1}
           });
            PersonController controller = new PersonController(_repositoryMock.Object);
            var persons = controller.Get();
            Assert.AreEqual(persons.Count(), 1);
            Assert.AreEqual(persons.First().Id, 1);
            _repositoryMock.Verify(x => x.GetAll(), Times.Once);
        }

        [Test]
        public void PutShouldReturnSuccess()
        {
            var person = new Person() { Id = 1 };
            _repositoryMock.Setup(x => x.Update(person)).Returns(person);
            PersonController controller = new PersonController(_repositoryMock.Object);
            var persons = controller.Put(person);
            Assert.IsNotNull(person);
            Assert.AreEqual(person.Id, 1);
            _repositoryMock.Verify(x => x.Update(It.IsAny<Person>()), Times.Once);
        }
        [TestCase(1,1)]
        [TestCase(Int32.MaxValue,1)]
        [TestCase(1, Int32.MaxValue)]
        [TestCase(Int32.MinValue, Int32.MaxValue)]
        [TestCase(Int32.MaxValue, Int32.MinValue)]
        [TestCase(Int32.MaxValue, Int32.MaxValue)]
        public void AddMethodShouldReturnSum(int i, int j)
        {
            PersonController controller = new PersonController(_repositoryMock.Object);
            //var sum = controller.Add(i, j);
            //Assert.AreEqual(sum, i + j);

            //Assert.Throws<DivideByZeroException>(() => { controller.Divide(i, 0); });
            //// sum = controller.Add(Int32.MinValue, Int32.MinValue);
            // Assert.AreEqual(sum, 2 * Int32.MinValue);
        }
    }
    class DummyRepository : IRepository<Person>
    {
        public int Delete(int id)
        {
            throw new System.NotImplementedException();
        }

        public BaseEntity Get(int id)
        {
            throw new System.NotImplementedException();
        }

        public List<BaseEntity> GetAll()
        {
            return new List<BaseEntity>()
           {
               new Person(){Id =1}
           };
        }

        public BaseEntity Insert(BaseEntity person)
        {
            throw new System.NotImplementedException();
        }

        public BaseEntity Update(BaseEntity person)
        {
            throw new System.NotImplementedException();
        }
    }
}