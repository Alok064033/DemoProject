using Moq;
using MyFirstWebApi.Controllers;
using MyFirstWebApi.Models;
using MyFirstWebApi.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using Xunit.Sdk;

namespace MyFirstWebApi.XUnit.Tests
{
    public class UnitTest1
    {
        Mock<IRepository<Person>> _repositoryMock;

        [Fact]
        public void GetShouldReturnResultWhenItemsAreInDatabase()
        {
            _repositoryMock = new Mock<IRepository<Person>>();

            //PersonController controller = new PersonController(new DummyRepository());
            _repositoryMock.Setup(x => x.GetAll()).Returns(new List<BaseEntity>()
           {
               new Person(){Id =1}
           });
            PersonController controller = new PersonController(_repositoryMock.Object);
            var persons = controller.Get();
            Assert.Equal(persons.Count(), 1);
            Assert.Equal(persons.First().Id, 1);
            _repositoryMock.Verify(x => x.GetAll(), Times.Once);
        }
    }
}
