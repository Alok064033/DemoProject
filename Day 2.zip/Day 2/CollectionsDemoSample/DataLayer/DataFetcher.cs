﻿using LoggingLayer;

namespace DataLayer
{
    public class DataFetcher
    {
       // ILogger logger = new TextLogger();
        ILogger logger = LoggerFactory.GetInstance("Text");
        public string GetData()
        {
            logger.Log("Get Data Called : Getting data from database");
            //Get data from database 
            return string.Empty;
        }
    }
}
