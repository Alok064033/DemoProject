﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoggingLayer
{
    public interface ILogger
    {
        void Log(string message);
    }

    public class LoggerFactory
    {
        public static ILogger GetInstance(string logType)
        {
            switch (logType)
            {
                case "Text":
                    return new TextLogger();
                case "Sql":
                    return new SqlLogger();
                case "Legacy":
                    return new LegacyLoggerAdapter();
                default:
                    throw new ArgumentException("Invalid log type");
            }
        }
    }


    class TextLogger : ILogger
    {
        public void Log(string message)
        {
            //Log to text file
        }
    }

    class SqlLogger : ILogger
    {
        public void Log(string message)
        {
            //Log to database
        }
    }
    //Adapter
    class LegacyLoggerAdapter : ILogger
    {
        //Composition
        LegacyLogger legacyLogger = new LegacyLogger();

        public void Log(string message)
        {
            //Delegation
            legacyLogger.Log(message);
        }
    }
    class LegacyLogger 
    {
        public void Log(string message)
        {
            //Log to Legacy IBM Db2 databse
        }
    }
}
