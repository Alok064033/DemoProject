﻿using DataLayer;
using LoggingLayer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace CollectionsDemoSample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnArray_Click(object sender, EventArgs e)
        {
            int[] iArray = new int[2];
            iArray[0] = 0;
            iArray[1] = 1;
            int[] iArray2 = new int[2] { 2,1};
            int[] iArray3 = {0,1};

            for (int i = 0; i < iArray.Length; i++)
            {
                Console.WriteLine(iArray[i]);
            }
            foreach (int item in iArray)
            {
                Console.WriteLine(item);
            }
            IEnumerator enumerator = iArray.GetEnumerator();
            while (enumerator.MoveNext())
            {
                Console.WriteLine(enumerator.Current);
            }
            iArray.CopyTo(iArray2, 0);

            iArray.SetValue(3, 0);
            iArray[0] = 3;

            var value = iArray.GetValue(0);
            value = iArray[0];

            int[] clonedArray = iArray.Clone() as int[];

            var areEqual = iArray.Equals(clonedArray);

            var iArray2D = new int[2, 2] { { 1, 2 }, { 3, 4 } };
            var rows = iArray2D.GetLength(0);
            var columns = iArray2D.GetLength(1);

            for (int i = 0; i < iArray2D.GetLength(0); i++)
            {
                for (int j = 0; j < iArray2D.GetLength(1); j++)
                {
                    Console.WriteLine(iArray2D[i, j]);
                }
            }
            foreach (var item in iArray2D)
            {
                Console.WriteLine(item);
            }

            var iJaggedArray = new int[2][];
            iJaggedArray[0] = new int[2];
            iJaggedArray[1] = new int[3];
            //Array size is fixed
            //Insertion and deletion is not possible
            //Collection of similar data types

            int j1 = 10;
            object obj = j1; // Boxing
            j1 = Convert.ToInt32(obj); //Unboxing

        }

        private void btnArrayList_Click(object sender, EventArgs e)
        {
            ArrayList list = new ArrayList();
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");
            list.Add(1);
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");
            list.Add("2");
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");
            list.AddRange(new int[] {  3,1,5});
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");

            var index = list.IndexOf(1);
            var lastIndex = list.LastIndexOf(1);
            list.Insert(0, 4);
            list.InsertRange(0, new int[] { 6,7});

            list.SetRange( 0, new int[] { 1, 1 });

            list.Remove(1);
            list.RemoveAt(1);
            list.RemoveRange(0, 2);
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list[i]);
            }
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            var enu = list.GetEnumerator();
            while (enu.MoveNext())
            {
                Console.WriteLine(enu.Current);
            }
            //Arraylist can grow
            // Can hold multiple data types
            // Problem of boxing and unboxing
            // No type checking since you can accidently add any incompatible type

            list.Clear();
        }

        private void btnGenericList_Click(object sender, EventArgs e)
        {
            List<int> list = new List<int>();
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");
            list.Add(1);
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");
            list.Add(2);
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");
            list.AddRange(new int[] { 3, 1, 5 });
            Console.WriteLine($"Count is {list.Count} and capacity is {list.Capacity}");

            var index = list.IndexOf(1);
            var lastIndex = list.LastIndexOf(1);
            list.Insert(0, 4);
            list.InsertRange(0, new int[] { 6, 7 });

            //list.SetRange(0, new int[] { 1, 1 });

            list.Remove(1);
            list.RemoveAt(1);
            list.RemoveRange(0, 2);
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine(list[i]);
            }
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            var enu = list.GetEnumerator();
            while (enu.MoveNext())
            {
                Console.WriteLine(enu.Current);
            }
            //It can grow
            // Cannot hold multiple data types
            // No Problem of boxing and unboxing
            // Strong type checking

            list.Clear();
        }

        private void btnCustomCollection_Click(object sender, EventArgs e)
        {
            CustomCollection list = new CustomCollection();
            list.Add(1);
            list.Add(1);
            list.Add(1);
            list.Add(1);
            list.Add(1);
            //list.Count = 0;
            //for (int i = 0; i < list.Count; i++)
            //{
            //    Console.WriteLine(list[i]);
            //}

            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

            CustomCollection<long> listOfLongs = new CustomCollection<long>();
            listOfLongs.Add(1);
            listOfLongs.Add(1);
            listOfLongs.Add(1);
            listOfLongs.Add(1);
            listOfLongs.Add(1);
            foreach (var item in listOfLongs)
            {
                Console.WriteLine(item);
            }
        }

        private void btnDictionary_Click(object sender, EventArgs e)
        {
            Dictionary<int, string> employees = new Dictionary<int, string>();
            employees.Add(1, "Test");
            employees.Add(2, "Test2");
            employees.Add(3, "Test3");
            if(!employees.ContainsKey(3))
                employees.Add(3, "Test3");

            foreach (var key in employees.Keys)
            {
                Console.WriteLine(key);
            }
            foreach (var value     in employees.Values)
            {
                Console.WriteLine(value);
            }
            foreach (var item in employees)
            {
                Console.WriteLine(item.Key + item.Value);
            }

            IDictionaryEnumerator dictionaryEnumerator = employees.GetEnumerator();
            while (dictionaryEnumerator.MoveNext())
            {
                Console.WriteLine(dictionaryEnumerator.Key.ToString() + dictionaryEnumerator.Value);
            }
        }

        private void btnOtherCollections_Click(object sender, EventArgs e)
        {
            //System.Collections.
            //
            //System.Collections.Specialized.OrderedDictionary
            //System.Collections.Generic.SortedList<int, string>

        }

        private void btnExtensionMethods_Click(object sender, EventArgs e)
        {
            DateTime datetime = DateTime.Now;

            Console.WriteLine(datetime.ToString("MM/dd/yyyy"));
            Console.WriteLine(datetime.ToBusinessDateString());
            Console.WriteLine(datetime.ToString("MM-dd-yyyy"));
            var date = Extensions.ToBusinessDateString(datetime);
        }

        private void btnExceptionHandling_Click(object sender, EventArgs e)
        {
            try
            {
                TestExceptionThrow();
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }

        private static void TestExceptionThrow()
        {
            StreamReader reader = null;
            string s = "this is a test";
            try
            {
                reader = File.OpenText("test.txt");
                int i = Convert.ToInt32(s);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            catch (Exception ex2)
            {
                Console.WriteLine(ex2.Message);
                throw ex2;
            }
            finally
            {
                reader.Close();
            }
        }
        public void Display(string data)
        {
            Console.WriteLine(data);
        }

        private const string Path = "Test";

        //ILogger logger = new TextLogger();
        object logger = LoggerFactory.GetInstance("Text");
        DataFetcher fetcher = new DataFetcher();
        private void btnEnterpriseArchitecture_Click(object sender, EventArgs e)
        {
            //var logger = LoggerFactory.GetInstance("Text");
            var type = logger.GetType();
            //object instance =  Activator.CreateInstance(type);
            var methodInfo = type.GetMethod("Log");
            methodInfo.Invoke(logger,new object[] { "Getting data from database" });

            //logger.Log("Getting data from database");
            var data = fetcher.GetData();
            Display(data);

            var legacyLogger = LoggerFactory.GetInstance("Legacy");
            legacyLogger.Log("Test");
        }

        private void btnDriveDirectoryFile_Click(object sender, EventArgs e)
        {
            DirectoryInfo dir = null;
            if (!Directory.Exists(Path))
            {
                dir = Directory.CreateDirectory(Path);
            }
            else
                dir = new DirectoryInfo(Path);
            Console.WriteLine(dir.FullName);

            dir.CreateSubdirectory("Child");

            DriveInfo driveInfo = new DriveInfo("C:");
           
            foreach (var dirInfo in driveInfo.RootDirectory.GetDirectories())
            {
                Console.WriteLine(dirInfo.FullName);
            }
            var filePath = "Test/test.txt";
            
            if (!File.Exists(filePath))
                File.WriteAllText(filePath, "This is a test content");
            var content = File.ReadAllLines("Test/test.txt");
            File.Delete(filePath);
            dir.Delete();
        }

        private void btnFileStream_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("test2.txt", FileMode.CreateNew);
            string content = "This is a string content";

            System.Text.ASCIIEncoding encoding = new ASCIIEncoding();
            var bytes = encoding.GetBytes(content);

            fs.Write(bytes,0, bytes.Length);
            fs.Close();
            fs.Dispose();

            using (FileStream fsRead = new FileStream("test2.txt", FileMode.Open))
            {
                byte[] bytes1 = new byte[fsRead.Length];
                fsRead.Read(bytes1, 0, bytes1.Length);

                Console.WriteLine(encoding.GetString(bytes1));
            }
              
        }

        private async void btnStreamReaderWriter_Click(object sender, EventArgs e)
        {
            using (StreamWriter streamWriter = new StreamWriter("test3.txt"))
            {
               await streamWriter.WriteLineAsync("This is some content ");
               await streamWriter.WriteAsync("This is some content ");
            }

            using (StreamReader streamReader = new StreamReader("test3.txt"))
            {
                while (!streamReader.EndOfStream)
                {
                    Console.WriteLine(await streamReader.ReadLineAsync());
                }
            }

            //MemoryMappedFile
        }

        private void btnMemoryStream_Click(object sender, EventArgs e)
        {
            MemoryStream memoryStream = new MemoryStream();
            System.Text.ASCIIEncoding encoding = new ASCIIEncoding();
            var bytes = encoding.GetBytes("This is some text");
            memoryStream.Write(bytes, 0, bytes.Length);
            memoryStream.Write(bytes, 0, bytes.Length);

            byte[] buffer = new byte[memoryStream.Length];
            memoryStream.Read(buffer, 0, buffer.Length);

            FileStream fs = new FileStream("test4.txt",FileMode.Create);
            memoryStream.WriteTo(fs);
        }

        private void btnXmlReaderWriter_Click(object sender, EventArgs e)
        {
            XmlReader reader = XmlReader.Create("person.xml");
            //XmlWriter writer = XmlWriter.Create("person.xml");
            while (reader.Read())
            {
                if ( reader.NodeType == XmlNodeType.Element)    
                    Console.WriteLine(reader.Name);
            }
            reader.Close();
            reader.Dispose();

        }

        private void btnLinq_Click(object sender, EventArgs e)
        {
            int[] iArray = new int[] { 1, 2, 3, 4, 5, 6 };

            List<int> listEven = new List<int>();
            foreach (var item in iArray)
            {
                if (item % 2 == 0)
                    listEven.Add(item);
            }
            List<int> listDivisibleBy3 = new List<int>();
            foreach (var item in iArray)
            {
                if (item % 3 == 0)
                    listDivisibleBy3.Add(item);
            }
            Func<int, bool> func = new Func<int, bool>(GenerateMethod);
            var list =  iArray.Where(func);
            list = iArray.Where(GenerateMethod);
            list = iArray.Where((int item) =>
            {
                    return item % 3 == 0;
            });
            list = iArray.Where(item =>
            {
                return item % 3 == 0;
            });
            list = iArray.Where(item => item % 3 == 0);
            list = iArray.Where(item => item % 2 == 0);

            list.Aggregate((int i, int j) => i + j);
            list.Aggregate((i,j) => i + j);

            var listOf100 = Enumerable.Range(1, 100);
            listOf100.Aggregate((i, j) => i + j);
            listOf100.Aggregate((i, j) => i*i + j*j);


            var listOfEvens = listOf100.FindXList(i => i % 2 == 0);
        }
      
        public List<int> FindEvenList (List<int> iArray)
        {
            List<int> list = new List<int>();
            foreach (var item in iArray)
            {
                if (item % 2 == 0)
                    list.Add(item);
            }
            return list;
        }
        public List<int> FindOddList(List<int> iArray)
        {
            List<int> list = new List<int>();
            foreach (var item in iArray)
            {
                if (item % 2 != 0)
                    list.Add(item);
            }
            return list;
        }
        private bool GenerateMethod(int item)
        {
            return item % 3 == 0;
        }

        private void btnThread_Click(object sender, EventArgs e)
        {
            Thread thread = new Thread(Print);
            thread.Start();
            //Print();
            for (int i = 11; i < 20; i++)
            {
                Console.WriteLine(i);
            }
            Thread parameterized  = new Thread(ParameterizedThreadStart);
            parameterized.Start(1);
        }

        private void ParameterizedThreadStart(object print)
        {
            
        }

        private void Print()
        {
            for (int i = 0; i < 10000; i++)
            {
                Console.WriteLine(i);
            }
        }

        private void btnTask_Click(object sender, EventArgs e)
        {
            Task task = new TaskFactory().StartNew(Print);
            //task.Start();

           // task.Wait();
            Task task2 = new Task(Print);
            task2.Start();
        }

        private void btnRaceCondition_Click(object sender, EventArgs e)
        {
            Task task = new TaskFactory().StartNew(Increment);           
            Task task2 = new Task(Increment);
            task2.Start();
        }

        static int j;
        static object locker = new object();
        void Increment()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine(j);
                lock(locker)
                {
                    j++;
                }
              //  Thread.Sleep(100);
                Task.Delay(100);
            }
            
        }

        private async void btnMoreOnTasks_Click(object sender, EventArgs e)
        {
            Task<int> task = new TaskFactory().StartNew(Data);
            Task<int> task2 = new Task<int>(Data);
            task2.Start();
            //await Task.WhenAny(task, task2);
            await task;
            if ( task.Exception != null)
            {
                int result = task.Result;

            }
            Console.WriteLine("Hi");
        }

        int Data()
        {
            return 1;
        }

        private void btnWriteToDatabase_Click(object sender, EventArgs e)
        {
            OleDbConnection oleDbConnection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Shakti-PC\\Desktop\Employee.accdb;Persist Security Info=False;");

            OleDbCommand oleDbCommand = new OleDbCommand("Select * from employees", oleDbConnection);
            oleDbConnection.Open();

            OleDbDataReader reader = oleDbCommand.ExecuteReader();
            while (reader.Read())
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine(reader.GetName(i) + reader.GetValue(i).ToString());
                }
            }
            oleDbConnection.Close();
            oleDbConnection.Dispose();      
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            using (OleDbConnection oleDbConnection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Shakti-PC\\Desktop\Employee.accdb;Persist Security Info=False;"))
            {
                //OleDbCommand oleDbCommand = new OleDbCommand("insert into employees values (2, 'Test' , 22, 22000,'11/18/1980' )", oleDbConnection);
                OleDbCommand oleDbCommand = new OleDbCommand("insert into employees values (@id , @name , @age, @salary, @dob )", oleDbConnection);
                oleDbCommand.Parameters.AddWithValue("id", 3);
                oleDbCommand.Parameters.AddWithValue("name", "Test2");
                oleDbCommand.Parameters.AddWithValue("age", 39);
                oleDbCommand.Parameters.AddWithValue("salary", 399999);
                oleDbCommand.Parameters.AddWithValue("dob",DateTime.Parse( "11/18/1980"));
                oleDbConnection.Open();

                int result = oleDbCommand.ExecuteNonQuery();
            }
        }

        private void btnDataAdapterRead_Click(object sender, EventArgs e)
        {
            DataSet dataSet = GetDataIntoDataset();
            foreach (DataTable table in dataSet.Tables)
            {
                foreach (DataRow row in table.Rows)
                {
                    foreach (DataColumn column in table.Columns)
                    {
                        Console.WriteLine(row[column]);
                    }

                }
            }
        }

        private static DataSet GetDataIntoDataset()
        {
            OleDbConnection oleDbConnection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Shakti-PC\\Desktop\Employee.accdb;Persist Security Info=False;");

            OleDbCommand oleDbCommand = new OleDbCommand("Select * from employees", oleDbConnection);
            // oleDbConnection.Open();

            OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(oleDbCommand);
            DataSet dataSet = new DataSet();
            oleDbDataAdapter.Fill(dataSet);
            return dataSet;
        }

        private void btnWriteXml_Click(object sender, EventArgs e)
        {
            DataSet dataSet = GetDataIntoDataset();
            dataSet.WriteXml("employees.xml");
            dataSet.WriteXmlSchema("employees.xsd");

            DataSet dataSet2 = new DataSet();
            dataSet2.ReadXml("employees.xml");

        }

        private void btnDataAdapterUpdate_Click(object sender, EventArgs e)
        {
            OleDbConnection oleDbConnection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Shakti-PC\\Desktop\Employee.accdb;Persist Security Info=False;");

            OleDbCommand oleDbCommand = new OleDbCommand("Select * from employees", oleDbConnection);
            // oleDbConnection.Open();

            OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(oleDbCommand);
            DataSet dataSet = new DataSet();
            oleDbDataAdapter.Fill(dataSet);

            dataSet.Tables[0].Rows.Add(new object[] {4, "Test2", 22, 22000, DateTime.Parse("11/18/1980") });
            var dataRow = dataSet.Tables[0].NewRow();
            dataRow["ID"] = 5;
            dataRow["FullName"] = "Test5";
            dataRow["Age"] = 55;
            dataRow["Salary"] = 555555;
            dataRow["DOB"] = DateTime.Parse("11/18/1980");
            dataSet.Tables[0].Rows.Add(dataRow);

            dataSet.Tables[0].Rows[1]["FullName"] = "This is changed";
            dataSet.Tables[0].Rows.RemoveAt(0);
            dataSet.WriteXml("diff.xml",XmlWriteMode.DiffGram);
            OleDbCommandBuilder builder = new OleDbCommandBuilder(oleDbDataAdapter);
            oleDbDataAdapter.Update(dataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnTransactions_Click(object sender, EventArgs e)
        {
                    
            using (OleDbConnection oleDbConnection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\\Users\\Shakti-PC\\Desktop\Employee.accdb;Persist Security Info=False;"))
            {
                
                OleDbCommand oleDbCommand2 = new OleDbCommand("insert into employees values (7, 'Test' , 22, 22000,'18/18/1980' )", oleDbConnection);

                OleDbCommand oleDbCommand = new OleDbCommand("insert into employees values (@id , @name , @age, @salary, @dob )", oleDbConnection);
                oleDbCommand.Parameters.AddWithValue("id", 8);
                oleDbCommand.Parameters.AddWithValue("name", "Test2");
                oleDbCommand.Parameters.AddWithValue("age", 39);
                oleDbCommand.Parameters.AddWithValue("salary", 399999);
                oleDbCommand.Parameters.AddWithValue("dob", DateTime.Parse("11/18/1980"));
                oleDbConnection.Open();

                var transaction = oleDbConnection.BeginTransaction();
                try
                {
                    oleDbCommand.Transaction = transaction;
                    oleDbCommand2.Transaction = transaction;
                    int result = oleDbCommand.ExecuteNonQuery();
                    result = oleDbCommand2.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                   // throw;
                }
                
            }
        }

        private void btnDynamic_Click(object sender, EventArgs e)
        {
            dynamic obj = GetInstance("Text");
            obj.TestM();
        }

        public static dynamic GetInstance(string logType)
        {
            switch (logType)
            {
                case "Text":
                    return new Test();
                case "Sql":
                    return new Test2();
              
                default:
                    throw new ArgumentException("Invalid log type");
            }
        }

        class Test
        {
            public void TestM()
            {

            }
        }
        class Test2
        {
            public void TestM()
            {

            }
        }

        private void btnAutomapper_Click(object sender, EventArgs e)
        {
            var person = new Person() { Id = 1, Name = "test" };
            
            var employee = new Employee();
            foreach (PropertyInfo info in person.GetType().GetProperties())
            {
               var target = employee.GetType().GetProperty(info.Name);
                if (target != null)
                {
                    target.SetValue(employee, info.GetValue(person));

                }
                else
                {
                    var attr = info.GetCustomAttribute(typeof(MapToAttribute));
                    if ( attr != null)
                    {
                       var name =  (attr as MapToAttribute).Name;
                        target = employee.GetType().GetProperty(name);
                        target.SetValue(employee, info.GetValue(person));
                    }

                }
            }
        }
        class MapToAttribute : Attribute
        {
            public MapToAttribute(string name)
            {
                Name = name;
            }

            public string Name { get; }
        }
        class Employee
        {
            public string Name { get; set; }
           
            public int EmployeeId { get; set; }
        }
        class Person
        {
            public string Name { get; set; }
            [MapToAttribute("EmployeeId")]
            public int Id { get; set; }
        }
    }
}
