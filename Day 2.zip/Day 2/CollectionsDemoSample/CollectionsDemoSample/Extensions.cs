﻿using System;
using System.Collections.Generic;

namespace CollectionsDemoSample
{
    public static class Extensions
    {
        /// <summary>
        /// Please use this method instead of ToString else you will have penalty 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>string</returns>
        public static string ToBusinessDateString(this DateTime dt)
        {
            return dt.ToString("MM/dd/yyyy");
        }

        public static List<int> FindXList(this IEnumerable<int> iArray, Func<int, bool> condition)
        {
            List<int> list = new List<int>();
            foreach (var item in iArray)
            {
                if (condition(item))
                    list.Add(item);
            }
            return list;
        }
        public static string FullName(this IHuman human)
        {
            return human.FirstName + human.LastName;
        }
    }
}
