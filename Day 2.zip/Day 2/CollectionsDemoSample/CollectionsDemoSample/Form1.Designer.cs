﻿namespace CollectionsDemoSample
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnArray = new System.Windows.Forms.Button();
            this.btnArrayList = new System.Windows.Forms.Button();
            this.btnGenericList = new System.Windows.Forms.Button();
            this.btnCustomCollection = new System.Windows.Forms.Button();
            this.btnDictionary = new System.Windows.Forms.Button();
            this.btnOtherCollections = new System.Windows.Forms.Button();
            this.btnExtensionMethods = new System.Windows.Forms.Button();
            this.btnExceptionHandling = new System.Windows.Forms.Button();
            this.btnEnterpriseArchitecture = new System.Windows.Forms.Button();
            this.btnFileStream = new System.Windows.Forms.Button();
            this.btnDriveDirectoryFile = new System.Windows.Forms.Button();
            this.btnStreamReaderWriter = new System.Windows.Forms.Button();
            this.btnMemoryStream = new System.Windows.Forms.Button();
            this.btnXmlReaderWriter = new System.Windows.Forms.Button();
            this.btnLinq = new System.Windows.Forms.Button();
            this.btnThread = new System.Windows.Forms.Button();
            this.btnTask = new System.Windows.Forms.Button();
            this.btnRaceCondition = new System.Windows.Forms.Button();
            this.btnMoreOnTasks = new System.Windows.Forms.Button();
            this.btnWriteToDatabase = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.btnDatasetWriteXml = new System.Windows.Forms.Button();
            this.btnWriteXml = new System.Windows.Forms.Button();
            this.btnDataAdapterUpdate = new System.Windows.Forms.Button();
            this.btnTransactions = new System.Windows.Forms.Button();
            this.btnDynamic = new System.Windows.Forms.Button();
            this.btnAutomapper = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnArray
            // 
            this.btnArray.Location = new System.Drawing.Point(29, 12);
            this.btnArray.Name = "btnArray";
            this.btnArray.Size = new System.Drawing.Size(159, 23);
            this.btnArray.TabIndex = 0;
            this.btnArray.Text = "Array";
            this.btnArray.UseVisualStyleBackColor = true;
            this.btnArray.Click += new System.EventHandler(this.btnArray_Click);
            // 
            // btnArrayList
            // 
            this.btnArrayList.Location = new System.Drawing.Point(29, 42);
            this.btnArrayList.Name = "btnArrayList";
            this.btnArrayList.Size = new System.Drawing.Size(159, 23);
            this.btnArrayList.TabIndex = 1;
            this.btnArrayList.Text = "ArrayList";
            this.btnArrayList.UseVisualStyleBackColor = true;
            this.btnArrayList.Click += new System.EventHandler(this.btnArrayList_Click);
            // 
            // btnGenericList
            // 
            this.btnGenericList.Location = new System.Drawing.Point(29, 72);
            this.btnGenericList.Name = "btnGenericList";
            this.btnGenericList.Size = new System.Drawing.Size(159, 23);
            this.btnGenericList.TabIndex = 2;
            this.btnGenericList.Text = "List<T>";
            this.btnGenericList.UseVisualStyleBackColor = true;
            this.btnGenericList.Click += new System.EventHandler(this.btnGenericList_Click);
            // 
            // btnCustomCollection
            // 
            this.btnCustomCollection.Location = new System.Drawing.Point(29, 104);
            this.btnCustomCollection.Name = "btnCustomCollection";
            this.btnCustomCollection.Size = new System.Drawing.Size(159, 23);
            this.btnCustomCollection.TabIndex = 3;
            this.btnCustomCollection.Text = "Custom Collection";
            this.btnCustomCollection.UseVisualStyleBackColor = true;
            this.btnCustomCollection.Click += new System.EventHandler(this.btnCustomCollection_Click);
            // 
            // btnDictionary
            // 
            this.btnDictionary.Location = new System.Drawing.Point(29, 139);
            this.btnDictionary.Name = "btnDictionary";
            this.btnDictionary.Size = new System.Drawing.Size(159, 23);
            this.btnDictionary.TabIndex = 4;
            this.btnDictionary.Text = "Dictionary";
            this.btnDictionary.UseVisualStyleBackColor = true;
            this.btnDictionary.Click += new System.EventHandler(this.btnDictionary_Click);
            // 
            // btnOtherCollections
            // 
            this.btnOtherCollections.Location = new System.Drawing.Point(29, 177);
            this.btnOtherCollections.Name = "btnOtherCollections";
            this.btnOtherCollections.Size = new System.Drawing.Size(159, 23);
            this.btnOtherCollections.TabIndex = 5;
            this.btnOtherCollections.Text = "Other Collections";
            this.btnOtherCollections.UseVisualStyleBackColor = true;
            this.btnOtherCollections.Click += new System.EventHandler(this.btnOtherCollections_Click);
            // 
            // btnExtensionMethods
            // 
            this.btnExtensionMethods.Location = new System.Drawing.Point(224, 12);
            this.btnExtensionMethods.Name = "btnExtensionMethods";
            this.btnExtensionMethods.Size = new System.Drawing.Size(159, 23);
            this.btnExtensionMethods.TabIndex = 6;
            this.btnExtensionMethods.Text = "Extension Methods";
            this.btnExtensionMethods.UseVisualStyleBackColor = true;
            this.btnExtensionMethods.Click += new System.EventHandler(this.btnExtensionMethods_Click);
            // 
            // btnExceptionHandling
            // 
            this.btnExceptionHandling.Location = new System.Drawing.Point(224, 43);
            this.btnExceptionHandling.Name = "btnExceptionHandling";
            this.btnExceptionHandling.Size = new System.Drawing.Size(159, 23);
            this.btnExceptionHandling.TabIndex = 7;
            this.btnExceptionHandling.Text = "Exception Handling";
            this.btnExceptionHandling.UseVisualStyleBackColor = true;
            this.btnExceptionHandling.Click += new System.EventHandler(this.btnExceptionHandling_Click);
            // 
            // btnEnterpriseArchitecture
            // 
            this.btnEnterpriseArchitecture.Location = new System.Drawing.Point(224, 74);
            this.btnEnterpriseArchitecture.Name = "btnEnterpriseArchitecture";
            this.btnEnterpriseArchitecture.Size = new System.Drawing.Size(159, 23);
            this.btnEnterpriseArchitecture.TabIndex = 8;
            this.btnEnterpriseArchitecture.Text = "Enterprise Architecture";
            this.btnEnterpriseArchitecture.UseVisualStyleBackColor = true;
            this.btnEnterpriseArchitecture.Click += new System.EventHandler(this.btnEnterpriseArchitecture_Click);
            // 
            // btnFileStream
            // 
            this.btnFileStream.Location = new System.Drawing.Point(419, 47);
            this.btnFileStream.Name = "btnFileStream";
            this.btnFileStream.Size = new System.Drawing.Size(159, 23);
            this.btnFileStream.TabIndex = 9;
            this.btnFileStream.Text = "FileStream";
            this.btnFileStream.UseVisualStyleBackColor = true;
            this.btnFileStream.Click += new System.EventHandler(this.btnFileStream_Click);
            // 
            // btnDriveDirectoryFile
            // 
            this.btnDriveDirectoryFile.Location = new System.Drawing.Point(419, 12);
            this.btnDriveDirectoryFile.Name = "btnDriveDirectoryFile";
            this.btnDriveDirectoryFile.Size = new System.Drawing.Size(159, 23);
            this.btnDriveDirectoryFile.TabIndex = 10;
            this.btnDriveDirectoryFile.Text = "Drive/Directory/File";
            this.btnDriveDirectoryFile.UseVisualStyleBackColor = true;
            this.btnDriveDirectoryFile.Click += new System.EventHandler(this.btnDriveDirectoryFile_Click);
            // 
            // btnStreamReaderWriter
            // 
            this.btnStreamReaderWriter.Location = new System.Drawing.Point(419, 83);
            this.btnStreamReaderWriter.Name = "btnStreamReaderWriter";
            this.btnStreamReaderWriter.Size = new System.Drawing.Size(159, 23);
            this.btnStreamReaderWriter.TabIndex = 11;
            this.btnStreamReaderWriter.Text = "StreamReader/Writer";
            this.btnStreamReaderWriter.UseVisualStyleBackColor = true;
            this.btnStreamReaderWriter.Click += new System.EventHandler(this.btnStreamReaderWriter_Click);
            // 
            // btnMemoryStream
            // 
            this.btnMemoryStream.Location = new System.Drawing.Point(419, 118);
            this.btnMemoryStream.Name = "btnMemoryStream";
            this.btnMemoryStream.Size = new System.Drawing.Size(159, 23);
            this.btnMemoryStream.TabIndex = 12;
            this.btnMemoryStream.Text = "MemoryStream";
            this.btnMemoryStream.UseVisualStyleBackColor = true;
            this.btnMemoryStream.Click += new System.EventHandler(this.btnMemoryStream_Click);
            // 
            // btnXmlReaderWriter
            // 
            this.btnXmlReaderWriter.Location = new System.Drawing.Point(419, 156);
            this.btnXmlReaderWriter.Name = "btnXmlReaderWriter";
            this.btnXmlReaderWriter.Size = new System.Drawing.Size(159, 23);
            this.btnXmlReaderWriter.TabIndex = 13;
            this.btnXmlReaderWriter.Text = "XmlReader/Writer";
            this.btnXmlReaderWriter.UseVisualStyleBackColor = true;
            this.btnXmlReaderWriter.Click += new System.EventHandler(this.btnXmlReaderWriter_Click);
            // 
            // btnLinq
            // 
            this.btnLinq.Location = new System.Drawing.Point(29, 220);
            this.btnLinq.Name = "btnLinq";
            this.btnLinq.Size = new System.Drawing.Size(159, 23);
            this.btnLinq.TabIndex = 14;
            this.btnLinq.Text = "Linq";
            this.btnLinq.UseVisualStyleBackColor = true;
            this.btnLinq.Click += new System.EventHandler(this.btnLinq_Click);
            // 
            // btnThread
            // 
            this.btnThread.Location = new System.Drawing.Point(419, 252);
            this.btnThread.Name = "btnThread";
            this.btnThread.Size = new System.Drawing.Size(159, 23);
            this.btnThread.TabIndex = 15;
            this.btnThread.Text = "Thread";
            this.btnThread.UseVisualStyleBackColor = true;
            this.btnThread.Click += new System.EventHandler(this.btnThread_Click);
            // 
            // btnTask
            // 
            this.btnTask.Location = new System.Drawing.Point(419, 297);
            this.btnTask.Name = "btnTask";
            this.btnTask.Size = new System.Drawing.Size(159, 23);
            this.btnTask.TabIndex = 16;
            this.btnTask.Text = "Task";
            this.btnTask.UseVisualStyleBackColor = true;
            this.btnTask.Click += new System.EventHandler(this.btnTask_Click);
            // 
            // btnRaceCondition
            // 
            this.btnRaceCondition.Location = new System.Drawing.Point(419, 341);
            this.btnRaceCondition.Name = "btnRaceCondition";
            this.btnRaceCondition.Size = new System.Drawing.Size(159, 23);
            this.btnRaceCondition.TabIndex = 17;
            this.btnRaceCondition.Text = "Race Condition";
            this.btnRaceCondition.UseVisualStyleBackColor = true;
            this.btnRaceCondition.Click += new System.EventHandler(this.btnRaceCondition_Click);
            // 
            // btnMoreOnTasks
            // 
            this.btnMoreOnTasks.Location = new System.Drawing.Point(419, 386);
            this.btnMoreOnTasks.Name = "btnMoreOnTasks";
            this.btnMoreOnTasks.Size = new System.Drawing.Size(159, 23);
            this.btnMoreOnTasks.TabIndex = 18;
            this.btnMoreOnTasks.Text = "More On Tasks";
            this.btnMoreOnTasks.UseVisualStyleBackColor = true;
            this.btnMoreOnTasks.Click += new System.EventHandler(this.btnMoreOnTasks_Click);
            // 
            // btnWriteToDatabase
            // 
            this.btnWriteToDatabase.Location = new System.Drawing.Point(29, 278);
            this.btnWriteToDatabase.Name = "btnWriteToDatabase";
            this.btnWriteToDatabase.Size = new System.Drawing.Size(159, 23);
            this.btnWriteToDatabase.TabIndex = 19;
            this.btnWriteToDatabase.Text = "Read From Database";
            this.btnWriteToDatabase.UseVisualStyleBackColor = true;
            this.btnWriteToDatabase.Click += new System.EventHandler(this.btnWriteToDatabase_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(29, 307);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(159, 23);
            this.btnWrite.TabIndex = 20;
            this.btnWrite.Text = "Write To Database";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // btnDatasetWriteXml
            // 
            this.btnDatasetWriteXml.Location = new System.Drawing.Point(29, 336);
            this.btnDatasetWriteXml.Name = "btnDatasetWriteXml";
            this.btnDatasetWriteXml.Size = new System.Drawing.Size(159, 23);
            this.btnDatasetWriteXml.TabIndex = 21;
            this.btnDatasetWriteXml.Text = "Dataset Write";
            this.btnDatasetWriteXml.UseVisualStyleBackColor = true;
            this.btnDatasetWriteXml.Click += new System.EventHandler(this.btnDataAdapterRead_Click);
            // 
            // btnWriteXml
            // 
            this.btnWriteXml.Location = new System.Drawing.Point(29, 364);
            this.btnWriteXml.Name = "btnWriteXml";
            this.btnWriteXml.Size = new System.Drawing.Size(159, 23);
            this.btnWriteXml.TabIndex = 22;
            this.btnWriteXml.Text = "Dataset WriteXml";
            this.btnWriteXml.UseVisualStyleBackColor = true;
            this.btnWriteXml.Click += new System.EventHandler(this.btnWriteXml_Click);
            // 
            // btnDataAdapterUpdate
            // 
            this.btnDataAdapterUpdate.Location = new System.Drawing.Point(29, 393);
            this.btnDataAdapterUpdate.Name = "btnDataAdapterUpdate";
            this.btnDataAdapterUpdate.Size = new System.Drawing.Size(159, 23);
            this.btnDataAdapterUpdate.TabIndex = 23;
            this.btnDataAdapterUpdate.Text = "DataAdapter UPdate";
            this.btnDataAdapterUpdate.UseVisualStyleBackColor = true;
            this.btnDataAdapterUpdate.Click += new System.EventHandler(this.btnDataAdapterUpdate_Click);
            // 
            // btnTransactions
            // 
            this.btnTransactions.Location = new System.Drawing.Point(29, 422);
            this.btnTransactions.Name = "btnTransactions";
            this.btnTransactions.Size = new System.Drawing.Size(159, 23);
            this.btnTransactions.TabIndex = 24;
            this.btnTransactions.Text = "Transactions";
            this.btnTransactions.UseVisualStyleBackColor = true;
            this.btnTransactions.Click += new System.EventHandler(this.btnTransactions_Click);
            // 
            // btnDynamic
            // 
            this.btnDynamic.Location = new System.Drawing.Point(238, 139);
            this.btnDynamic.Name = "btnDynamic";
            this.btnDynamic.Size = new System.Drawing.Size(159, 23);
            this.btnDynamic.TabIndex = 25;
            this.btnDynamic.Text = "Dynamic";
            this.btnDynamic.UseVisualStyleBackColor = true;
            this.btnDynamic.Click += new System.EventHandler(this.btnDynamic_Click);
            // 
            // btnAutomapper
            // 
            this.btnAutomapper.Location = new System.Drawing.Point(616, 83);
            this.btnAutomapper.Name = "btnAutomapper";
            this.btnAutomapper.Size = new System.Drawing.Size(159, 23);
            this.btnAutomapper.TabIndex = 26;
            this.btnAutomapper.Text = "Automapper";
            this.btnAutomapper.UseVisualStyleBackColor = true;
            this.btnAutomapper.Click += new System.EventHandler(this.btnAutomapper_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAutomapper);
            this.Controls.Add(this.btnDynamic);
            this.Controls.Add(this.btnTransactions);
            this.Controls.Add(this.btnDataAdapterUpdate);
            this.Controls.Add(this.btnWriteXml);
            this.Controls.Add(this.btnDatasetWriteXml);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnWriteToDatabase);
            this.Controls.Add(this.btnMoreOnTasks);
            this.Controls.Add(this.btnRaceCondition);
            this.Controls.Add(this.btnTask);
            this.Controls.Add(this.btnThread);
            this.Controls.Add(this.btnLinq);
            this.Controls.Add(this.btnXmlReaderWriter);
            this.Controls.Add(this.btnMemoryStream);
            this.Controls.Add(this.btnStreamReaderWriter);
            this.Controls.Add(this.btnDriveDirectoryFile);
            this.Controls.Add(this.btnFileStream);
            this.Controls.Add(this.btnEnterpriseArchitecture);
            this.Controls.Add(this.btnExceptionHandling);
            this.Controls.Add(this.btnExtensionMethods);
            this.Controls.Add(this.btnOtherCollections);
            this.Controls.Add(this.btnDictionary);
            this.Controls.Add(this.btnCustomCollection);
            this.Controls.Add(this.btnGenericList);
            this.Controls.Add(this.btnArrayList);
            this.Controls.Add(this.btnArray);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnArray;
        private System.Windows.Forms.Button btnArrayList;
        private System.Windows.Forms.Button btnGenericList;
        private System.Windows.Forms.Button btnCustomCollection;
        private System.Windows.Forms.Button btnDictionary;
        private System.Windows.Forms.Button btnOtherCollections;
        private System.Windows.Forms.Button btnExtensionMethods;
        private System.Windows.Forms.Button btnExceptionHandling;
        private System.Windows.Forms.Button btnEnterpriseArchitecture;
        private System.Windows.Forms.Button btnFileStream;
        private System.Windows.Forms.Button btnDriveDirectoryFile;
        private System.Windows.Forms.Button btnStreamReaderWriter;
        private System.Windows.Forms.Button btnMemoryStream;
        private System.Windows.Forms.Button btnXmlReaderWriter;
        private System.Windows.Forms.Button btnLinq;
        private System.Windows.Forms.Button btnThread;
        private System.Windows.Forms.Button btnTask;
        private System.Windows.Forms.Button btnRaceCondition;
        private System.Windows.Forms.Button btnMoreOnTasks;
        private System.Windows.Forms.Button btnWriteToDatabase;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Button btnDatasetWriteXml;
        private System.Windows.Forms.Button btnWriteXml;
        private System.Windows.Forms.Button btnDataAdapterUpdate;
        private System.Windows.Forms.Button btnTransactions;
        private System.Windows.Forms.Button btnDynamic;
        private System.Windows.Forms.Button btnAutomapper;
    }
}

