﻿using System.Collections;

namespace CollectionsDemoSample
{
    internal class CustomCollection : IEnumerable
    {
        int[] _items;
        int _count = 0;
        public int Count { get => _count; }
        public int this[int index] { get => _items[index]; }

        //public int this[int index]
        //{
        //    get { return _items[index]; }
        //}

        //public void SetCount(int value)
        //{
        //    _count = value;
        //}
        //public int GetCount()
        //{
        //    return _count;
        //}
        public void Add(int i)
        {
            if (_items == null)
                _items = new int[4];
            if ( _count > _items.Length -1)
            {
                var temp = new int[Count * 2];
                _items.CopyTo(temp, 0);
                _items = temp;
            }
            _items[_count] = i;
            _count++;
        }

        

        public IEnumerator GetEnumerator()
        {
            return new CustomCollectionEnumerator(_items, Count);
            //return _items.GetEnumerator();
        }
    }

    class CustomCollectionEnumerator : IEnumerator
    {
        int[] _items;
        int _count = 0;
        public CustomCollectionEnumerator(int[] items, int count)
        {
            _items = items;
            _count = count;
        }
        int _currentIndex = -1;
        public object Current => _items[_currentIndex];

        public bool MoveNext()
        {
            if (_currentIndex < _count - 1)
            {
                _currentIndex += 1;
                return true;
            }
            return false;
        }

        public void Reset()
        {
            _currentIndex = -1;
        }
    }

    internal class CustomCollection<T> : IEnumerable
    {
        T[] _items;
        int _count = 0;
        public int Count { get => _count; }
        public T this[int index] { get => _items[index]; }

        public void Add(T i)
        {
            if (_items == null)
                _items = new T[4];
            if (_count > _items.Length - 1)
            {
                var temp = new T[Count * 2];
                _items.CopyTo(temp, 0);
                _items = temp;
            }
            _items[_count] = i;
            _count++;
        }



        public IEnumerator GetEnumerator()
        {
            return new CustomCollectionEnumerator<T>(_items, Count);
            //return _items.GetEnumerator();
        }
    }

    class CustomCollectionEnumerator<T> : IEnumerator
    {
        T[] _items;
        int _count = 0;
        public CustomCollectionEnumerator(T[] items, int count)
        {
            _items = items;
            _count = count;
        }
        int _currentIndex = -1;
        public object Current => _items[_currentIndex];

        public bool MoveNext()
        {
            if (_currentIndex < _count - 1)
            {
                _currentIndex += 1;
                return true;
            }
            return false;
        }

        public void Reset()
        {
            _currentIndex = -1;
        }
    }

}
