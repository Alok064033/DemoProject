﻿namespace CollectionsDemoSample
{
    public interface IHuman
    {
        string FirstName { get; set; }
        string LastName { get; set; }
    }
    class Person : IHuman
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
    class Employee : IHuman
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
