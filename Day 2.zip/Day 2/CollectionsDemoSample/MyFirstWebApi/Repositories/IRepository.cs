﻿using MyFirstWebApi.Models;
using System.Collections.Generic;
using System.Net.Mime;

namespace MyFirstWebApi.Repositories
{
    //public interface IOrderRepository
    //{
    //    public Order Get(int id);
    //    public List<Order> GetAll();
    //    public Order Insert(Order person);
    //    public Order Update(Order person);
    //    public int Delete(int id);
    //}
    public interface IRepository<T> where T : BaseEntity
    {
        public BaseEntity Get(int id);
        public List<BaseEntity> GetAll();
        public BaseEntity Insert (BaseEntity person);
        public BaseEntity Update (BaseEntity person);
        public int Delete(int id);
    }
}
