﻿using MyFirstWebApi.Models;
using System.Collections.Generic;
using System.Linq;

namespace MyFirstWebApi.Repositories
{
    public class PersonRepository : IRepository<Person>
    {
        private readonly PersonContext _context;
        public PersonRepository(PersonContext context)
        {
            _context = context;
        }
        public int Delete(int id)
        {
            var p = _context.Persons.FirstOrDefault(p => p.Id == id);
            _context.Persons.Remove(p);
            return _context.SaveChanges();
        }

        public BaseEntity Get(int id)
        {
            return _context.Persons.FirstOrDefault(p => p.Id == id);
        }

        public List<BaseEntity> GetAll()
        {
            return _context.Persons.ToList<BaseEntity>();
        }

        public BaseEntity Insert(BaseEntity person)
        {
            _context.Persons.Add(person as Person);
            _context.SaveChanges();
            return person;
        }

        public BaseEntity Update(BaseEntity person)
        {
            var personEntity = person as Person;
            var p = _context.Persons.FirstOrDefault(p => p.Id == personEntity.Id);
            //p.Name = personEntity.Name;
            //p.Age = personEntity.Age;
            p.Salary = personEntity.Salary;
            p.BirthDate = personEntity.BirthDate;
            _context.SaveChanges();
            return p;
        }
    }
}
