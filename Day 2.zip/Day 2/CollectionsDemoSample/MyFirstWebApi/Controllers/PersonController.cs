﻿using Microsoft.AspNetCore.Mvc;
using MyFirstWebApi.Models;
using MyFirstWebApi.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

namespace MyFirstWebApi.Controllers
{
    public class PersonController : BaseController
    {
        private readonly IRepository<Person> personRepository;
        // private readonly PersonContext context;

        //public PersonController(PersonContext context)
        //{
        //    this.context = context;
        //}
        public PersonController(IRepository<Person> personRepository)
        {
            this.personRepository = personRepository;
        }
        [HttpPost]
        public IActionResult Post(Person person)
        {
            if (ModelState.IsValid)
            {
                return Ok(personRepository.Insert(person) as Person);
            }
            return BadRequest();
            //context.Persons.Add(person);
            //context.SaveChanges();
            //return person;
        }

        [HttpGet]
        public IEnumerable<Person> Get()
        {
            return personRepository.GetAll().OfType<Person>();
           // return null;
            //return context.Persons.ToList();
            //return new List<Person>()
            //{
            //    new Person(){Id = 1, Name = "Test", BirthDate = DateTime.Now},
            //    new Person(){Id = 2, Name = "Test2"},
            //};
        }
        [HttpPut]
        public Person Put(Person person)
        {
            return personRepository.Update(person) as Person;
        }
        [HttpDelete]
        public int Delete(int id)
        {
            return personRepository.Delete(id);
        }

        //public int Add(int i, int j)
        //{
        //    return i + j;
        //}
        //public int Divide(int i, int j)
        //{
        //    return i / j;
        //}
    }
}
