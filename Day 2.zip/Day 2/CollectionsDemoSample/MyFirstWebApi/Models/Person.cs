﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata;

namespace MyFirstWebApi.Models
{
    public abstract class BaseEntity
    {
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
    //Attributes are runtime metadata
    //They provide info about your types/,ethods/properties at runtime
    public class Person : BaseEntity
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(20)]
        public string LastName { get; set; }
        [IsNotNullOrEmpty]
        public string Name { get; set; }
        [RegularExpression("^\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,3}$")]
        public string Email { get; set; }
        public byte Age { get; set; }
        [Range(18, 60)]
        public int Age2 { get; set; }
        public decimal Salary { get; set; }
        public DateTime BirthDate { get; set; }
    }

    public class PersonContext : DbContext
    {
        public DbSet<Person> Persons { get; set; }

        public string DbPath { get; }

        public PersonContext()
        {
            var folder = Environment.SpecialFolder.LocalApplicationData;
            var path = Environment.GetFolderPath(folder);
            DbPath = System.IO.Path.Join(path, "person.db");
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseSqlite($"Data Source={DbPath}");
    }

    public class IsNotNullOrEmpty : System.ComponentModel.DataAnnotations.ValidationAttribute
    {
       
        public override bool IsValid(object value)
        {
            if( value != null && !string.IsNullOrWhiteSpace(value.ToString()))
            {
                return true;
            }
            ErrorMessage = "Value cannot be null";
            return false;
        }
    }
}
