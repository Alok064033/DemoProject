﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace HelloWorldLib
{
    public interface IAccount
    {
        double Balance { get; set; }
        void Withdraw(double amount);
        void Deposit(double amount);
        void PrintBalance()
        {
            Console.WriteLine($"IAccount {Balance}"); 
        }
    }
    public interface IAccount2
    {
        double Balance { get; set; }
        void Withdraw(double amount);
        void Deposit(double amount);
        void PrintBalance()
        {
            Console.WriteLine($"IAccount2 {Balance}");
        }
    }
    public class SavingAccount : IAccount, IAccount2
    {
        public double Balance { get; set; }

        public void Deposit(double amount)
        {
           // Balance = Balance + amount;
            Balance += amount;
        }

        public void Withdraw(double amount)
        {
            Balance -= amount;
        }
        public void PrintBalance()
        {
            Console.WriteLine("From child" + Balance);
        }
    }
}
