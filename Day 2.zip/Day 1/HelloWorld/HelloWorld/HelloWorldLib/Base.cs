﻿namespace HelloWorldLib
{
    //Scenario 1 : Method present in Base and not hidden or overriden in child    
    //public class Base
    //{
    //    public virtual void Show()
    //    {
    //        Console.WriteLine("Hi");
    //    }
    //}

    //public class Child : Base
    //{

    //}

    //Scenario 2 : Method present in Base and hidden in child
    //public class Base
    //{
    //    public void Show()
    //    {
    //        Console.WriteLine("Hi");
    //    }
    //}

    //public class Child : Base
    //{
    //    public new void Show()
    //    {
    //        Console.WriteLine("Hi");
    //    }
    //}

    //Scenario 3 : Method present in Base and overriden in child
    public class Base
    {
        public virtual void Show()
        {
            Console.WriteLine("Hi");
        }
    }

    public class Child : Base
    {
        public override void Show()
        {
            Console.WriteLine("Hi");
        }
    }

}


