﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HelloWorldLib
{
    public class Animal
    {
        public Animal()
        {
            
        }

        public int Name
        {
            get => default;
            set
            {
            }
        }

        public void Run()
        {
            throw new System.NotImplementedException();
        }
    }

    public class Dog : Animal
    {
    }
}