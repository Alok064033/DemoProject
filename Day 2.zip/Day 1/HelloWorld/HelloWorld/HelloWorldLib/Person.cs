﻿namespace HelloWorldLib
{
    public class Person
    {
        public void Hello(string name)
        {
            Demo demo = new Demo();
            demo.i = 10;
            //demo.j = 10;
            //demo.k = 10;
            demo.l = 10;
            demo.m = 10;
            //demo.o = 10;
            //Demo.s = 10;
            Demo.t = 10;
           // Demo.u = 10;
            Console.WriteLine("Hello" + name);
            Console.WriteLine($"Hello {name}");
        }
    }

    public class DemoChild : Demo
    {
        public DemoChild()
        {
            i = 10;
            //j = 10;
            k = 10;
            l = 10;
            m = 10;
            o = 10;
            //s = 10;
            t = 10;
           // u = 10;
        }
    }
}