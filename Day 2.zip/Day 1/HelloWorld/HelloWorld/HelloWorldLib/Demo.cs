﻿namespace HelloWorldLib
{
    public class Demo
    {
        public int i;
        private int j;
        protected int k;
        internal int l;
        protected internal int m;
        private protected int o;
        static int s;
        public static int t;
        private static int u;
    }
}