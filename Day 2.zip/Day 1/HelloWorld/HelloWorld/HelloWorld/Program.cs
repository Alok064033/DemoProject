﻿//using HelloWorldLib;

using HelloWorldLib;

namespace HelloWorld
{
    public class Program
    {
        static int s = 0;
        static void Main(string[] args)
        {
            Base baseObject = new Base();
            Child childObject = new Child();
            Base castedFromChild = new Child();
            //Child childFromBase = new Base();
            baseObject.Show();
            childObject.Show();
            castedFromChild.Show();

            IAccount iAccount = new SavingAccount();
            IAccount2 iAccount2 = new SavingAccount();
            SavingAccount savingAccount = new SavingAccount();
            iAccount.PrintBalance();
            iAccount2.PrintBalance();

            iAccount.Withdraw(1000);
            iAccount2.Withdraw(1000);
            //savingAccount.PrintBalance();


            Demo demo = new Demo();
            demo.i = 10;
            //demo.j = 10;
            //demo.k = 10;
            //demo.l = 10;
            //demo.m = 10;
            //demo.o = 10;
            Demo.t = 10;
            

            HelloWorldLib.Person person = new HelloWorldLib.Person();
            person.Hello(args[0]);
            //Breakpoint F9
            //Run F5
            //Step Over F10
            //Step Into F11
            //Step out of current method Shift + F11
            // Comment Ctrl+ K + C
            //Uncomment Ctrl + K + U
            //Move between places traversed in code Ctrl -
            //Move forward to place in code Ctrl -             
            Display();
            Console.ReadLine();
        }

        static void Display()
        {
            int k = 0;
            Console.WriteLine(k);
        }

    }
    public class DemoChild : Demo
    {
        public DemoChild()
        {
            i = 10;
            //j = 10;
            k = 10;
            //l = 10;
            m = 10;
            //o = 10;
            //s = 10;
            t = 10;
            // u = 10;
        }
    }
}

//namespace HelloWorldDemo
//{
//    public class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Hello, World!");
//        }
//    }
//}